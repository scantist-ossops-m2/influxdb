// +build uint uint64

package models

func init() {
	EnableUintSupport()
}
