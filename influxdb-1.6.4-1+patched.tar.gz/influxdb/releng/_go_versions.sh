# These are the current and "next" Go versions used to build influxdb.
# This file is meant to be sourced from other scripts.

export GO_CURRENT_VERSION=1.10.3
export GO_NEXT_VERSION=1.10.3
